# Ngày 1 — Bài Tập & Phản Ánh
## Nền Tảng LLM API | Phiếu Thực Hành

**Thời lượng:** 1:30 giờ  
**Cấu trúc:** Lập trình cốt lõi (60 phút) → Bài tập mở rộng (30 phút)

---

## Phần 1 — Lập Trình Cốt Lõi (0:00–1:00)

Chạy các ví dụ trong Google Colab tại: https://colab.research.google.com/drive/172zCiXpLr1FEXMRCAbmZoqTrKiSkUERm?usp=sharing

Triển khai tất cả TODO trong `template.py`. Chạy `pytest tests/` để kiểm tra tiến độ.

**Điểm kiểm tra:** Sau khi hoàn thành 4 nhiệm vụ, chạy:
```bash
python template.py
```
Bạn sẽ thấy output so sánh phản hồi của GPT-4o và GPT-4o-mini.

---

## Phần 2 — Bài Tập Mở Rộng (1:00–1:30)

### Bài tập 2.1 — Độ Nhạy Của Temperature
Gọi `call_openai` với các giá trị temperature 0.0, 0.5, 1.0 và 1.5 sử dụng prompt **"Hãy kể cho tôi một sự thật thú vị về Việt Nam."**

**Bạn nhận thấy quy luật gì qua bốn phản hồi?** (2–3 câu)
> Khi temperature tăng từ 0.0 đến 1.5, phản hồi trở nên đa dạng, sáng tạo và ít có thể đoán trước hơn. Ở 0.0, thông tin thực tế và rập khuôn, ít thay đổi qua nhiều lần gọi. Đến 1.5, cách dùng từ phong phú hơn nhiều chiều, tuy nhiên có rủi ro bị lan man hoặc sinh ra các thông tin không chính xác (hallucination).

**Bạn sẽ đặt temperature bao nhiêu cho chatbot hỗ trợ khách hàng, và tại sao?**
> Tôi sẽ đặt ở mức thấp, khoảng 0.0 đến 0.2. Trong môi trường hỗ trợ khách hàng, tính chính xác, an toàn và nhất quán của thông tin được ưu tiên hàng đầu, do đó không cần thiết tính sáng tạo cao dễ dẫn tới sai lệch nội dung.

---

### Bài tập 2.2 — Đánh Đổi Chi Phí
Xem xét kịch bản: 10.000 người dùng hoạt động mỗi ngày, mỗi người thực hiện 3 lần gọi API, mỗi lần trung bình ~350 token.

**Ước tính xem GPT-4o đắt hơn GPT-4o-mini bao nhiêu lần cho workload này:**
> Xét theo chi phí output, giá GPT-4o là $0.010/1K token, GPT-4o-mini là $0.0006/1K token. Tỷ lệ = 0.010 / 0.0006 ≈ 16.67 lần. GPT-4o sẽ đắt hơn GPT-4o-mini khoảng 16.67 lần với cùng một workload, chưa tính chi phí input cũng có chênh lệch tương tự.

**Mô tả một trường hợp mà chi phí cao hơn của GPT-4o là xứng đáng, và một trường hợp GPT-4o-mini là lựa chọn tốt hơn:**
> GPT-4o là xứng đáng cho các bài toán suy luận phức tạp, code logic sâu, đọc hiểu tài liệu lớn/đa ngôn ngữ hoặc cần vision xuất sắc, vì nó chính xác hơn nhiều. Ngược lại, GPT-4o-mini là lựa chọn tốt hơn cho chatbot thường ngày, trích xuất dữ liệu rập khuôn khối lượng lớn, phân loại văn bản đơn giản nơi mà yêu cầu về suy luận không quá cao nhưng tiết kiệm được rất nhiều chi phí.

---

### Bài tập 2.3 — Trải Nghiệm Người Dùng với Streaming
**Streaming quan trọng nhất trong trường hợp nào, và khi nào thì non-streaming lại phù hợp hơn?** (1 đoạn văn)
> Streaming quan trọng nhất cho Chatbot ứng dụng giao diện hội thoại (trực tiếp với người dùng) giúp tối giản độ trễ cảm nhận (perceived latency), người dùng không cảm giác ứng dụng bị treo mà ngay lập tức thấy thông tin tuôn ra. Ngược lại, non-streaming phù hợp hơn trong kịch bản xử lý pipeline tự động, trích xuất dữ liệu (parse JSON), xử lý batch ngầm (không ai nhìn vào màn hình chờ kết quả) vì nó dễ viết code phản hồi và ít dính đến xử lý kết nối phức tạp.


## Danh Sách Kiểm Tra Nộp Bài
- [x] Tất cả tests pass: `pytest tests/ -v`
- [x] `call_openai` đã triển khai và kiểm thử
- [x] `call_openai_mini` đã triển khai và kiểm thử
- [x] `compare_models` đã triển khai và kiểm thử
- [x] `streaming_chatbot` đã triển khai và kiểm thử
- [x] `retry_with_backoff` đã triển khai và kiểm thử
- [x] `batch_compare` đã triển khai và kiểm thử
- [x] `format_comparison_table` đã triển khai và kiểm thử
- [x] `exercises.md` đã điền đầy đủ
- [x] Sao chép bài làm vào folder `solution` và đặt tên theo quy định 
